#Sat May 09 18:59:23 EDT 2020
lib/com.ibm.ws.javaee.platform.v8_1.0.40.jar=5ff42c3dbefcb57982481bd1607336b5
lib/features/com.ibm.websphere.appserver.javaeePlatform-8.0.mf=fd4431d804f4a4ac8b7169f3bbc7222e
lib/com.ibm.ws.javaee.version_1.0.40.jar=6ee1e3b95b24b63ee71fac4d8ec5b2e8
