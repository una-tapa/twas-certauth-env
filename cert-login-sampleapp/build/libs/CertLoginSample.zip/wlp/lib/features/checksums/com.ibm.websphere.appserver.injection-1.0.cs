#Sat May 09 18:59:23 EDT 2020
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=fd138a20705c9b3d1adb42b35e0668a3
lib/com.ibm.ws.injection_1.0.40.jar=ff6e25cceb3470fd94630cf839d3445c
