#Wed Apr 29 18:36:23 BST 2020
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=67f79bf5a597997075e943d2b787be2d
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.40.jar=79270fc3c807a057bfb4ce7767ea796e
lib/com.ibm.ws.logging.osgi_1.0.40.jar=5120aac702e1c258f36cf450f8854cf2
lib/com.ibm.ws.logging_1.0.40.jar=750ccbab7a6c36349b6eef12a10d83a5
lib/com.ibm.ws.collector.manager_1.0.40.jar=c004671fe53af579873c9152d1c2bf06
